﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace midCoreCrud.ViewModels
{
    public class VmContact
    {
        public int ContactId { get; set; }
        public string ContactName { get; set; }
        public int? CountryId { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public IFormFile PicPath { get; set; }
    }

}
