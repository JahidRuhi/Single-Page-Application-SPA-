﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace midCoreCrud.DataModels
{
    public partial class Contact
    {
        public int ContactId { get; set; }
        //[Required(ErrorMessage = "This Field is required.")]
        //[MaxLength(12, ErrorMessage = "Maximum 12 characters only")]
        public string ContactName { get; set; }
        //[Required(ErrorMessage = "This Field is required.")]
        public int? CountryId { get; set; }
        public string Gender { get; set; }
        //[Required(ErrorMessage = "This Field is required.")]
        public int? Age { get; set; }
        //[Required(ErrorMessage = "This Field is required.")]
        public DateTime? DateOfBirth { get; set; }
        public string PicPath { get; set; }
    }
}
