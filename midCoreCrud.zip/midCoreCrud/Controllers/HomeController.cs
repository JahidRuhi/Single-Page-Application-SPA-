﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using midCoreCrud.DataModels;
using midCoreCrud.Models;
using midCoreCrud.ViewModels;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace midCoreCrud.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public IActionResult SPA()
        {
            return View();
        }
        [HttpGet]
        public IActionResult Countries()
        {
            var _ctx = new SmsDbContext();
            return Json(_ctx.Country.OrderBy(x => x.CountryName).ToList());
        }
        [HttpGet]
        public IActionResult Contacts()
        {
            var _ctx = new SmsDbContext();
            var listContact = (from c in _ctx.Contact
                               join d in _ctx.Country on c.CountryId equals d.CountryId
                               select new
                               {
                                   c.ContactId,
                                   c.ContactName,
                                   c.CountryId,
                                   c.DateOfBirth,
                                   c.Gender,
                                   c.Age,
                                   c.PicPath,
                                   d.CountryName
                               }).ToList();
            return Json(listContact);
        }
        [HttpGet]
        public IActionResult Contact(int id)
        {
            var _ctx = new SmsDbContext();
            return Json(_ctx.Contact.Where(x => x.ContactId == id).FirstOrDefault());
        }
        [RequestSizeLimit(2147483648)]
        [HttpPost]
        public IActionResult ContactAdd([FromForm] VmContact contact)
        {
            object res = null; var _ctx = new SmsDbContext();
            var oContact = _ctx.Contact.Where(x => x.ContactId == contact.ContactId).FirstOrDefault();
            if (oContact == null)
            {

                string fileName = "";
                if (contact.PicPath != null)
                {
                    string path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/pics");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }
                    FileInfo fileInfo = new FileInfo(contact.PicPath.FileName);
                    string newFileName = DateTime.Now.ToString("yyyyMMddHHmmss");
                    fileName = newFileName + fileInfo.Extension;
                    string fileNameWithPath = Path.Combine(path, fileName);
                    using (var stream = new FileStream(fileNameWithPath, FileMode.Create))
                    {
                        contact.PicPath.CopyTo(stream);
                    }
                }
                oContact = new Contact();
                oContact.ContactName = contact.ContactName;
                oContact.CountryId = contact.CountryId;
                oContact.DateOfBirth = contact.DateOfBirth;
                oContact.Gender = contact.Gender;
                oContact.Age = contact.Age;
                oContact.PicPath = fileName;
                _ctx.Add(oContact);
                _ctx.SaveChanges();
                res = new
                {
                    resstate = true
                };
            }
            return Json(res);
        }
        [HttpPut]
        public IActionResult ContactEdit([FromForm] VmContact contact)
        {
            object res = null; var _ctx = new SmsDbContext();
            var oContact = _ctx.Contact.Where(x => x.ContactId == contact.ContactId).FirstOrDefault();
            if (oContact != null)
            {
                string fileName = "";
                if (contact.PicPath != null)
                {
                    string path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/pics");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }
                    FileInfo fileInfo = new FileInfo(contact.PicPath.FileName);
                    string newFileName = DateTime.Now.ToString("yyyyMMddHHmmss");
                    fileName = newFileName + fileInfo.Extension;
                    string fileNameWithPath = Path.Combine(path, fileName);
                    using (var stream = new FileStream(fileNameWithPath, FileMode.Create))
                    {
                        contact.PicPath.CopyTo(stream);
                    }
                    if (!string.IsNullOrEmpty(oContact.PicPath))
                    {
                        string fileNameWithPathDEL = Path.Combine(path, oContact.PicPath);
                        if (System.IO.File.Exists(fileNameWithPathDEL))
                        {
                            System.IO.File.Delete(fileNameWithPathDEL);
                        }
                    }
                }

                oContact.ContactName = contact.ContactName;
                oContact.CountryId = contact.CountryId;
                oContact.DateOfBirth = contact.DateOfBirth;
                oContact.Gender = contact.Gender;
                oContact.Age = contact.Age;
                oContact.PicPath = fileName;
                _ctx.SaveChanges();
                res = new
                {
                    resstate = true
                };
            }
            return Json(res);
        }
        [HttpDelete]
        public IActionResult ContactRemove([FromQuery] int id)
        {
            object res = null; var _ctx = new SmsDbContext();
            var oContact = _ctx.Contact.Where(x => x.ContactId == id).FirstOrDefault();
            if (oContact != null)
            {
                _ctx.Contact.Remove(oContact);
                _ctx.SaveChanges();
                string path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/pics");
                if (!string.IsNullOrEmpty(oContact.PicPath))
                {
                    string fileNameWithPathDEL = Path.Combine(path, oContact.PicPath);
                    if (System.IO.File.Exists(fileNameWithPathDEL))
                    {
                        System.IO.File.Delete(fileNameWithPathDEL);
                    }
                }
                res = new
                {
                    resstate = true
                };
            }
            return Json(res);
        }

    }
}
